# Core module - configuration, security, dependencies
